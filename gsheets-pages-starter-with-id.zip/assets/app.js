// Shared client helpers
// 1) Set your Apps Script Web App URL here (ends with /exec)
// 2) (Optional) set a SHARED_SECRET that matches the backend to deter abuse.

const API = "YOUR_APPS_SCRIPT_WEB_APP_URL"; // e.g., https://script.google.com/macros/s/AKfycbx.../exec
const SHARED_SECRET = ""; // set to e.g. "myStrongSecret123" and also update Code.gs

async function submitRow(data){
  const res = await fetch(API, {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({...data, _secret: SHARED_SECRET})
  });
  // Apps Script returns 200 + JSON; if your deployment/environment enforces CORS,
  // consider a small proxy (Cloudflare Worker) or enable referer/origin checks server-side.
  if(!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

async function fetchRows(){
  const url = API + "?view=rows";
  const res = await fetch(url, { method:"GET" });
  if(!res.ok) throw new Error(`HTTP ${res.status}`);
  // Returns a 2D array of rows: [[Timestamp,Name,Email,Phone,City], ...]
  return await res.json();
}
